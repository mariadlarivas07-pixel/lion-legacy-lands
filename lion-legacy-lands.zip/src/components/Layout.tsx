import { Outlet, Link, useLocation } from 'react-router-dom';

export default function Layout() {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <div className="min-h-screen flex flex-col bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 transition-colors duration-300">
      <nav className={`sticky top-0 z-50 w-full border-b backdrop-blur-md ${isHome ? 'border-slate-200 dark:border-white/10 bg-white/80 dark:bg-brand-900/80' : 'border-slate-200 dark:border-slate-800 bg-surface-light/80 dark:bg-surface-dark/80'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="material-icons-round text-brand-900">landscape</span>
              </div>
              <span className="text-xl font-bold tracking-tight text-brand-800 dark:text-white uppercase">Lion Legacy <span className="text-primary">Land</span></span>
            </Link>
            <div className="hidden md:flex items-center space-evenly gap-8">
              <Link to="/" className="text-sm font-medium hover:text-primary transition-colors">Cómo Funciona</Link>
              <Link to="/condados" className="text-sm font-medium hover:text-primary transition-colors">Condados</Link>
              <Link to="/casos-de-exito" className="text-sm font-medium hover:text-primary transition-colors">Casos de Éxito</Link>
              <Link to="/subastas" className="text-sm font-medium hover:text-primary transition-colors">Subastas Activas</Link>
              <button className="bg-primary hover:bg-opacity-90 text-brand-900 px-6 py-2.5 rounded-full font-semibold transition-all transform hover:scale-105">
                Explorar Condados
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow">
        <Outlet />
      </main>

      {isHome ? (
        <footer className="bg-brand-800 dark:bg-brand-950 text-white pt-24 pb-12 border-t border-white/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 mb-16">
              <div className="space-y-8">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
                    <span className="material-icons-round text-brand-900 text-lg">landscape</span>
                  </div>
                  <span className="text-lg font-bold uppercase tracking-tight">Lion Legacy <span className="text-primary">Land</span></span>
                </div>
                <h4 className="text-3xl font-display font-bold">Suscríbete a nuestro newsletter</h4>
                <p className="text-slate-400 max-w-md">Recibe oportunidades exclusivas y el análisis de mercado de Florida directamente en tu correo.</p>
                <form className="flex gap-2 max-w-md">
                  <input className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 flex-grow focus:outline-none focus:border-primary" placeholder="email@address.com" type="email"/>
                  <button className="bg-primary text-brand-900 px-6 py-3 rounded-xl font-bold hover:opacity-90 transition-all">Unirse</button>
                </form>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-8">
                <div>
                  <h5 className="font-bold mb-6 text-primary">Plataforma</h5>
                  <ul className="space-y-4 text-slate-400 text-sm">
                    <li><Link to="/" className="hover:text-white">Cómo funciona</Link></li>
                    <li><Link to="/condados" className="hover:text-white">Condados</Link></li>
                    <li><Link to="/subastas" className="hover:text-white">Calendario</Link></li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-bold mb-6 text-primary">Compañía</h5>
                  <ul className="space-y-4 text-slate-400 text-sm">
                    <li><a href="#" className="hover:text-white">Sobre nosotros</a></li>
                    <li><Link to="/casos-de-exito" className="hover:text-white">Casos de Éxito</Link></li>
                    <li><a href="#" className="hover:text-white">FAQ</a></li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-bold mb-6 text-primary">Legal</h5>
                  <ul className="space-y-4 text-slate-400 text-sm">
                    <li><a href="#" className="hover:text-white">Términos</a></li>
                    <li><a href="#" className="hover:text-white">Privacidad</a></li>
                    <li><a href="#" className="hover:text-white">Disclaimer</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
              <p className="text-slate-500 text-xs">© 2024 Lion Legacy Land. Todos los derechos reservados.</p>
            </div>
          </div>
        </footer>
      ) : (
        <footer className="bg-slate-100 dark:bg-slate-900/50 mt-20 py-12 border-t border-slate-200 dark:border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex flex-col gap-2 items-center md:items-start">
                <div className="font-black text-xl flex items-center gap-2">
                  <span className="material-icons-outlined text-primary">diamond</span>
                  LEGACY LANDS
                </div>
                <p className="text-xs text-slate-500">© 2024 Legacy Lands. Todos los derechos reservados.</p>
              </div>
              <div className="flex gap-8 text-sm font-medium text-slate-600 dark:text-slate-400">
                <a href="#" className="hover:text-primary transition-colors">Aviso Legal</a>
                <a href="#" className="hover:text-primary transition-colors">Privacidad</a>
                <a href="#" className="hover:text-primary transition-colors">Contacto</a>
              </div>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
