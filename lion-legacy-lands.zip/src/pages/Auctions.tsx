export default function Auctions() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <nav className="flex text-xs text-slate-500 dark:text-slate-400 mb-2 gap-2">
            <a className="hover:underline" href="#">Florida</a>
            <span>/</span>
            <a className="hover:underline" href="#">Alachua County</a>
            <span>/</span>
            <span className="text-primary font-medium">Active Auctions</span>
          </nav>
          <h1 className="text-3xl font-bold">Subastas Tax Deed Activas</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Explora oportunidades de inversión en tiempo real validadas por nuestro sistema.</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-surface-light dark:bg-surface-dark p-3 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center gap-3">
            <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded text-green-600 dark:text-green-400">
              <span className="material-icons-round text-sm">gavel</span>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Total Activas</p>
              <p className="text-lg font-bold leading-none">142</p>
            </div>
          </div>
          <div className="bg-surface-light dark:bg-surface-dark p-3 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center gap-3">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded text-blue-600 dark:text-blue-400">
              <span className="material-icons-round text-sm">monetization_on</span>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Valor Total</p>
              <p className="text-lg font-bold leading-none">$4.2M</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-surface-light dark:bg-surface-dark border border-slate-200 dark:border-slate-800 rounded-xl p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <div className="lg:col-span-2">
            <label className="block text-xs font-semibold text-slate-500 mb-1">Búsqueda rápida</label>
            <div className="relative">
              <span className="material-icons-round absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">search</span>
              <input className="w-full pl-9 pr-4 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 focus:ring-primary focus:border-primary transition-all" placeholder="Parcel ID o Dirección..." type="text"/>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Rango de Precio</label>
            <select className="w-full py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 focus:ring-primary focus:border-primary">
              <option>Todos los precios</option>
              <option>$0 - $50,000</option>
              <option>$50,000 - $150,000</option>
              <option>$150,000+</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Estado</label>
            <select className="w-full py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 focus:ring-primary focus:border-primary">
              <option>Todos</option>
              <option>Disponible</option>
              <option>En proceso</option>
              <option>Adjudicada</option>
            </select>
          </div>
          <div className="flex items-end gap-2 lg:col-span-2">
            <button className="flex-1 bg-primary hover:bg-opacity-90 text-white py-2 rounded-lg text-sm font-semibold transition-all flex items-center justify-center gap-2">
              <span className="material-icons-round text-sm">filter_alt</span>
              Aplicar Filtros
            </button>
            <button className="p-2 border border-slate-200 dark:border-slate-800 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-all text-slate-500">
              <span className="material-icons-round text-sm">refresh</span>
            </button>
          </div>
        </div>
      </div>

      <div className="bg-surface-light dark:bg-surface-dark border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Parcel ID</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Address / Location</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Market Value</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Min Bid</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-4 font-mono text-xs font-semibold text-primary">02193-000-00</td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">1922 Mississippi Ave</span>
                    <span className="text-xs text-slate-500">Englewood, FL 34224</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-right font-medium">$300,100.00</td>
                <td className="px-6 py-4 text-sm text-right font-bold text-green-600 dark:text-green-400">$24,500.00</td>
                <td className="px-6 py-4 text-center">
                  <span className="px-2 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-tight">Active Auction</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="px-3 py-1.5 bg-slate-900 dark:bg-primary text-white text-xs font-bold rounded shadow-sm hover:opacity-90 transition-all">Solicitar Análisis</button>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-4 font-mono text-xs font-semibold text-primary">08442-010-00</td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">4764 Coppola Dr</span>
                    <span className="text-xs text-slate-500">Mount Dora, FL 32757</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-right font-medium">$410,100.00</td>
                <td className="px-6 py-4 text-sm text-right font-bold text-green-600 dark:text-green-400">$38,200.00</td>
                <td className="px-6 py-4 text-center">
                  <span className="px-2 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-tight">Active Auction</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="px-3 py-1.5 bg-slate-900 dark:bg-primary text-white text-xs font-bold rounded shadow-sm hover:opacity-90 transition-all">Solicitar Análisis</button>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-4 font-mono text-xs font-semibold text-primary">11029-455-00</td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">5930 W Lincoln Cir W</span>
                    <span className="text-xs text-slate-500">Lake Worth, FL 33463</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-right font-medium">$260,100.00</td>
                <td className="px-6 py-4 text-sm text-right font-bold text-green-600 dark:text-green-400">$19,800.00</td>
                <td className="px-6 py-4 text-center">
                  <span className="px-2 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-[10px] font-bold uppercase tracking-tight">Closing Soon</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="px-3 py-1.5 bg-slate-900 dark:bg-primary text-white text-xs font-bold rounded shadow-sm hover:opacity-90 transition-all">Solicitar Análisis</button>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-4 font-mono text-xs font-semibold text-primary">05521-002-01</td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">2803 NW 11th St</span>
                    <span className="text-xs text-slate-500">Cape Coral, FL 33993</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-right font-medium">$25,200.00</td>
                <td className="px-6 py-4 text-sm text-right font-bold text-green-600 dark:text-green-400">$4,500.00</td>
                <td className="px-6 py-4 text-center">
                  <span className="px-2 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 text-[10px] font-bold uppercase tracking-tight">Vacant Land</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="px-3 py-1.5 bg-slate-900 dark:bg-primary text-white text-xs font-bold rounded shadow-sm hover:opacity-90 transition-all">Solicitar Análisis</button>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-4 font-mono text-xs font-semibold text-primary">03381-005-00</td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-sm">26515 Eager Rd</span>
                    <span className="text-xs text-slate-500">Punta Gorda, FL 33955</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-right font-medium">$11,300.00</td>
                <td className="px-6 py-4 text-sm text-right font-bold text-green-600 dark:text-green-400">$1,200.00</td>
                <td className="px-6 py-4 text-center">
                  <span className="px-2 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 text-[10px] font-bold uppercase tracking-tight">Vacant Land</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="px-3 py-1.5 bg-slate-900 dark:bg-primary text-white text-xs font-bold rounded shadow-sm hover:opacity-90 transition-all">Solicitar Análisis</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-500">Mostrando 1 a 5 de 142 resultados</span>
          <div className="flex gap-2">
            <button className="px-3 py-1 border border-slate-300 dark:border-slate-700 rounded text-xs font-medium hover:bg-white dark:hover:bg-slate-800 transition-all disabled:opacity-50" disabled>Anterior</button>
            <button className="px-3 py-1 bg-primary text-white rounded text-xs font-medium">1</button>
            <button className="px-3 py-1 border border-slate-300 dark:border-slate-700 rounded text-xs font-medium hover:bg-white dark:hover:bg-slate-800 transition-all">2</button>
            <button className="px-3 py-1 border border-slate-300 dark:border-slate-700 rounded text-xs font-medium hover:bg-white dark:hover:bg-slate-800 transition-all">3</button>
            <button className="px-3 py-1 border border-slate-300 dark:border-slate-700 rounded text-xs font-medium hover:bg-white dark:hover:bg-slate-800 transition-all">Siguiente</button>
          </div>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-4 bg-slate-100 dark:bg-slate-800/50 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <span className="material-icons-round text-primary text-lg">info</span>
            <h4 className="text-sm font-bold">¿Cómo funciona?</h4>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">Cada listado representa una propiedad en subasta por falta de pago de impuestos. El "Min Bid" es el punto de partida legal.</p>
        </div>
        <div className="p-4 bg-slate-100 dark:bg-slate-800/50 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <span className="material-icons-round text-primary text-lg">analytics</span>
            <h4 className="text-sm font-bold">Análisis Experto</h4>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">Solicita un análisis profundo para recibir detalles sobre gravámenes, estado de la estructura y potencial de mercado.</p>
        </div>
        <div className="p-4 bg-slate-100 dark:bg-slate-800/50 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <span className="material-icons-round text-primary text-lg">verified_user</span>
            <h4 className="text-sm font-bold">Datos Verificados</h4>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">Nuestra plataforma sincroniza directamente con los registros de los condados cada 4 horas para garantizar precisión.</p>
        </div>
      </div>
    </div>
  );
}
