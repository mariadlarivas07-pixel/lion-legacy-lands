export default function SuccessCases() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-12">
        <div className="flex items-center gap-2 mb-4">
          <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Resultados Reales</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold mb-4 tracking-tight">
          🥇 Biblioteca de Casos de Éxito
        </h1>
        <p className="text-lg text-slate-600 dark:text-slate-400 max-w-3xl leading-relaxed">
          Invertir en bienes raíces <span className="text-primary font-semibold">no requiere millones</span>. Estos son casos reales de propiedades vendidas en subasta, con presupuestos variados y precios muy por debajo del valor de mercado.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-8 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white dark:bg-slate-700 shadow-sm font-medium text-sm">
            <span className="material-icons-round text-sm">grid_view</span> Vista de galería
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-white/50 dark:hover:bg-slate-700/50 font-medium text-sm transition-all">
            <span className="material-icons-round text-sm">table_rows</span> Tabla
          </button>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:flex-initial">
            <span className="material-icons-round absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">search</span>
            <input className="w-full md:w-64 pl-10 pr-4 py-2 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-lg text-sm focus:ring-primary focus:border-primary" placeholder="Buscar por condado o ciudad..." type="text"/>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
            <span className="material-icons-round text-sm">filter_list</span> Filtrar
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
            <span className="material-icons-round text-sm">sort</span> Ordenar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Case 1 */}
        <div className="group bg-card-light dark:bg-card-dark rounded-2xl overflow-hidden shadow-lg border border-slate-100 dark:border-slate-800 hover:shadow-2xl transition-all duration-300">
          <div className="relative h-56">
            <img alt="Villa in Charlotte, Florida" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/charlotte/600/400" referrerPolicy="no-referrer" />
            <div className="absolute top-4 left-4">
              <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
                <span className="material-icons-round text-sm">check_circle</span> SOLD AT AUCTION
              </span>
            </div>
            <div className="absolute bottom-4 right-4">
              <span className="bg-black/60 backdrop-blur-md text-white px-3 py-1 rounded-lg text-sm font-bold">
                Tax Deed
              </span>
            </div>
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-primary font-bold text-2xl">$300,100.00</p>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-medium flex items-center gap-1">
                  <span className="material-icons-round text-sm">location_on</span> Charlotte, Florida
                </p>
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
                <span className="material-icons-round text-slate-400">house</span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-sm">
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Camas</span>
                <span className="font-bold">5 bd</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Baños</span>
                <span className="font-bold">4.5 ba</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Sqft</span>
                <span className="font-bold">4,552</span>
              </div>
            </div>
            <div className="mt-6">
              <p className="text-xs text-slate-400 italic">1922 Mississippi Ave, Englewood, FL 34224</p>
            </div>
          </div>
        </div>

        {/* Case 2 */}
        <div className="group bg-card-light dark:bg-card-dark rounded-2xl overflow-hidden shadow-lg border border-slate-100 dark:border-slate-800 hover:shadow-2xl transition-all duration-300">
          <div className="relative h-56">
            <img alt="Luxury home in Lake County" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/lake/600/400" referrerPolicy="no-referrer" />
            <div className="absolute top-4 left-4">
              <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
                <span className="material-icons-round text-sm">check_circle</span> SOLD AT AUCTION
              </span>
            </div>
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-primary font-bold text-2xl">$410,100.00</p>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-medium flex items-center gap-1">
                  <span className="material-icons-round text-sm">location_on</span> Lake, Florida
                </p>
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
                <span className="material-icons-round text-slate-400">house</span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-sm">
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Camas</span>
                <span className="font-bold">5 bd</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Baños</span>
                <span className="font-bold">3 ba</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Sqft</span>
                <span className="font-bold">3,626</span>
              </div>
            </div>
            <div className="mt-6">
              <p className="text-xs text-slate-400 italic">4764 Coppola Dr, Mount Dora, FL 32757</p>
            </div>
          </div>
        </div>

        {/* Case 3 */}
        <div className="group bg-card-light dark:bg-card-dark rounded-2xl overflow-hidden shadow-lg border border-slate-100 dark:border-slate-800 hover:shadow-2xl transition-all duration-300">
          <div className="relative h-56">
            <img alt="Home in Palm Beach" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/palmbeach/600/400" referrerPolicy="no-referrer" />
            <div className="absolute top-4 left-4">
              <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
                <span className="material-icons-round text-sm">check_circle</span> SOLD AT AUCTION
              </span>
            </div>
          </div>
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-primary font-bold text-2xl">$260,100.00</p>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-medium flex items-center gap-1">
                  <span className="material-icons-round text-sm">location_on</span> Palm Beach, Florida
                </p>
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
                <span className="material-icons-round text-slate-400">house</span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-sm">
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Camas</span>
                <span className="font-bold">3 bd</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Baños</span>
                <span className="font-bold">2 ba</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400 text-xs uppercase font-bold tracking-tight">Sqft</span>
                <span className="font-bold">1,572</span>
              </div>
            </div>
            <div className="mt-6">
              <p className="text-xs text-slate-400 italic">5930 W Lincoln Cir W, Lake Worth, FL 33463</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16 flex flex-col items-center">
        <button className="flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-primary dark:hover:text-primary transition-colors font-medium">
          <span className="material-icons-round">expand_more</span> Cargar más casos de éxito
        </button>
        <div className="mt-8 p-6 bg-primary/5 border border-primary/20 rounded-2xl max-w-2xl text-center">
          <h3 className="font-bold text-lg mb-2">¿Quieres ser el próximo caso de éxito?</h3>
          <p className="text-slate-600 dark:text-slate-400 text-sm mb-4">Únete a nuestra plataforma y accede a la información más precisa sobre subastas de Tax Deeds en Florida.</p>
          <button className="bg-primary hover:bg-yellow-600 text-black px-8 py-3 rounded-full font-bold shadow-lg shadow-primary/20 transition-all">
            Empezar ahora
          </button>
        </div>
      </div>
    </div>
  );
}
