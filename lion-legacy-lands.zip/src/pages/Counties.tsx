import { Link } from 'react-router-dom';

export default function Counties() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-10">
        <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
          <span className="material-icons-outlined text-primary text-4xl">explore</span>
          Explora los condados de Florida
        </h1>
        <p className="text-slate-600 dark:text-slate-400 max-w-2xl">
          Revisa lo que ofrece cada uno, selecciona tus tres favoritos ❤️ y <a className="text-primary hover:underline" href="#">contáctanos</a> para más información detallada sobre oportunidades de inversión.
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8 bg-white dark:bg-card-dark p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex flex-wrap items-center gap-3">
              <button className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 text-primary border border-primary/20 rounded-lg text-sm font-medium">
                <span className="material-icons-outlined text-sm">grid_view</span>
                Condados
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-sm font-medium">
                <span className="material-icons-outlined text-sm">list_alt</span>
                Registro
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-sm font-medium">
                <span className="material-icons-outlined text-sm">map</span>
                Mapa
              </button>
              <div className="h-6 w-[1px] bg-slate-200 dark:bg-slate-800 mx-2"></div>
              <div className="relative group">
                <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium border border-transparent hover:border-slate-300 dark:hover:border-slate-600">
                  Tipo de Subasta: Todos
                  <span className="material-icons-outlined text-xs">expand_more</span>
                </button>
              </div>
              <button className="flex items-center gap-2 px-3 py-1.5 text-slate-500 text-xs hover:text-primary transition-colors">
                <span className="material-icons-outlined text-xs">add</span>
                Más Filtros
              </button>
            </div>
            <div className="flex items-center gap-4">
              <span className="material-icons-outlined text-slate-400 cursor-pointer hover:text-primary">filter_list</span>
              <span className="material-icons-outlined text-slate-400 cursor-pointer hover:text-primary">swap_vert</span>
              <div className="relative">
                <span className="material-icons-outlined absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 text-sm">search</span>
                <input className="pl-8 pr-3 py-1.5 bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm focus:ring-1 focus:ring-primary w-40" placeholder="Buscar..." type="text"/>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            <Link to="/condados/alachua" className="group relative bg-white dark:bg-card-dark rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer">
              <div className="aspect-[4/3] overflow-hidden relative">
                <img alt="Gainesville Alachua" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/alachua/600/400" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 county-card-overlay flex items-center justify-center">
                  <h3 className="text-white text-3xl font-black tracking-widest uppercase">Gainesville</h3>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs font-bold text-primary flex items-center gap-1 uppercase tracking-wider mb-1">
                      <span className="material-icons-outlined text-[14px]">location_on</span>
                      Alachua
                    </p>
                    <span className="inline-block px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold rounded">ONLINE</span>
                  </div>
                  <div className="flex items-center text-yellow-500">
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star_half</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 text-[10px] text-slate-500 font-medium">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> 1ª Subasta</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> 2ª Subasta</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500"></span> 3ª Subasta</span>
                </div>
              </div>
            </Link>

            <div className="group relative bg-white dark:bg-card-dark rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer">
              <div className="aspect-[4/3] overflow-hidden relative">
                <img alt="Macclenny Baker" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/baker/600/400" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 county-card-overlay flex items-center justify-center">
                  <h3 className="text-white text-3xl font-black tracking-widest uppercase">Macclenny</h3>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs font-bold text-primary flex items-center gap-1 uppercase tracking-wider mb-1">
                      <span className="material-icons-outlined text-[14px]">location_on</span>
                      Baker
                    </p>
                    <span className="inline-block px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold rounded">ONLINE</span>
                  </div>
                  <div className="flex items-center text-yellow-500">
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                  </div>
                </div>
                <div className="flex gap-2 text-[10px] text-slate-500 font-medium">
                  <span className="italic text-slate-400">Sin subastas próximas</span>
                </div>
              </div>
            </div>

            <div className="group relative bg-white dark:bg-card-dark rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer">
              <div className="aspect-[4/3] overflow-hidden relative">
                <img alt="Fort Lauderdale Broward" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/broward/600/400" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 county-card-overlay flex items-center justify-center">
                  <h3 className="text-white text-3xl font-black tracking-widest uppercase text-center px-4">Fort Lauderdale</h3>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs font-bold text-primary flex items-center gap-1 uppercase tracking-wider mb-1">
                      <span className="material-icons-outlined text-[14px]">location_on</span>
                      Broward *
                    </p>
                    <span className="inline-block px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold rounded">ONLINE</span>
                  </div>
                  <div className="flex items-center text-yellow-500">
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 text-[10px] text-slate-500 font-medium">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> 1ª Subasta</span>
                </div>
              </div>
            </div>

            <div className="group relative bg-white dark:bg-card-dark rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer">
              <div className="aspect-[4/3] overflow-hidden relative">
                <img alt="Melbourne Brevard" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://picsum.photos/seed/brevard/600/400" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 county-card-overlay flex items-center justify-center">
                  <h3 className="text-white text-3xl font-black tracking-widest uppercase">Melbourne</h3>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-xs font-bold text-primary flex items-center gap-1 uppercase tracking-wider mb-1">
                      <span className="material-icons-outlined text-[14px]">location_on</span>
                      Brevard
                    </p>
                    <span className="inline-block px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold rounded">ONLINE</span>
                  </div>
                  <div className="flex items-center text-yellow-500">
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm">star</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                    <span className="material-icons-outlined text-sm text-slate-300">star</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 text-[10px] text-slate-500 font-medium">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"></span> 1ª Subasta</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 flex justify-center">
            <button className="flex items-center gap-2 px-8 py-3 bg-white dark:bg-card-dark border border-slate-200 dark:border-slate-800 rounded-xl font-semibold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <span className="material-icons-outlined text-sm">expand_more</span>
              Cargar más condados
            </button>
          </div>
        </div>

        <aside className="w-full lg:w-80 flex flex-col gap-8">
          <div className="bg-white dark:bg-card-dark p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <h4 className="text-sm font-bold flex items-center gap-2 mb-6">
              <span className="material-icons-outlined text-primary">analytics</span>
              County-Level Trends
            </h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between group cursor-pointer">
                <div className="flex items-center gap-3">
                  <span className="material-icons-outlined text-lg text-slate-400">corporate_fare</span>
                  <span className="text-sm font-medium hover:text-primary">Miami Dade</span>
                </div>
                <span className="material-icons-outlined text-sm text-slate-300 group-hover:text-primary">chevron_right</span>
              </div>
              <div className="flex items-center justify-between group cursor-pointer">
                <div className="flex items-center gap-3">
                  <span className="material-icons-outlined text-lg text-slate-400">landscape</span>
                  <span className="text-sm font-medium hover:text-primary">Orange</span>
                </div>
                <span className="material-icons-outlined text-sm text-slate-300 group-hover:text-primary">chevron_right</span>
              </div>
              <div className="flex items-center justify-between group cursor-pointer">
                <div className="flex items-center gap-3">
                  <span className="material-icons-outlined text-lg text-slate-400">water</span>
                  <span className="text-sm font-medium hover:text-primary">Marion</span>
                </div>
                <span className="material-icons-outlined text-sm text-slate-300 group-hover:text-primary">chevron_right</span>
              </div>
              <div className="flex items-center justify-between group cursor-pointer">
                <div className="flex items-center gap-3">
                  <span className="material-icons-outlined text-lg text-slate-400">apartment</span>
                  <span className="text-sm font-medium hover:text-primary">Duval</span>
                </div>
                <span className="material-icons-outlined text-sm text-slate-300 group-hover:text-primary">chevron_right</span>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-card-dark p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <h4 className="text-sm font-bold flex items-center gap-2 mb-4 uppercase tracking-wider text-slate-500">
              <span className="material-icons-outlined text-sm">straight</span>
              Condados líderes en:
            </h4>
            <div className="mb-6">
              <p className="text-xs font-bold text-slate-400 mb-3 flex items-center gap-2">
                <span className="material-icons-outlined text-[14px]">terrain</span> LOTES SUBASTADOS
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><span className="text-primary font-bold">01</span> Lee</li>
                <li className="flex items-center gap-2"><span className="text-primary font-bold">02</span> Putnam</li>
                <li className="flex items-center gap-2"><span className="text-primary font-bold">03</span> Charlotte</li>
              </ul>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 mb-3 flex items-center gap-2">
                <span className="material-icons-outlined text-[14px]">home</span> CASAS SUBASTADAS
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><span className="text-primary font-bold">01</span> Alachua</li>
                <li className="flex items-center gap-2"><span className="text-primary font-bold">02</span> Escambia</li>
                <li className="flex items-center gap-2"><span className="text-primary font-bold">03</span> Palm Beach</li>
              </ul>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
