import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <>
      <section className="relative overflow-hidden pt-20 pb-32 hero-gradient">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute top-0 -left-1/4 w-1/2 h-full bg-primary/20 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-0 -right-1/4 w-1/2 h-full bg-brand-800/40 blur-[120px] rounded-full"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold tracking-widest uppercase">
              <span className="material-icons-round text-sm">verified</span>
              Plataforma Líder en Tax Deeds
            </div>
            <h1 className="text-5xl lg:text-7xl font-display text-white leading-tight">
              Invertir en subastas es más <span className="text-primary italic">simple</span> de lo que imaginas.
            </h1>
            <p className="text-lg text-slate-300 max-w-xl leading-relaxed">
              Accede a propiedades previamente seleccionadas y evaluadas por nuestro equipo. Toma decisiones con tranquilidad, sin datos dispersos ni información incompleta.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/subastas" className="px-8 py-4 bg-primary text-brand-900 rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:shadow-2xl hover:shadow-primary/20 transition-all">
                <span className="material-icons-round">explore</span>
                Comenzar Ahora
              </Link>
              <Link to="/casos-de-exito" className="px-8 py-4 bg-white/10 text-white border border-white/20 rounded-xl font-bold text-lg hover:bg-white/20 transition-all text-center">
                Ver Casos de Éxito
              </Link>
            </div>
          </div>
          <div className="relative hidden lg:block">
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl border border-white/10 group">
              <img alt="Lujosa propiedad en Florida" className="w-full h-[500px] object-cover transition-transform duration-700 group-hover:scale-105" src="https://picsum.photos/seed/miami/800/1000" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-900 via-transparent to-transparent"></div>
              <div className="absolute bottom-8 left-8 p-6 glass rounded-xl max-w-xs">
                <p className="text-white font-semibold text-lg">Miami Dade County</p>
                <p className="text-primary text-sm">Próxima Subasta: 15 Oct</p>
              </div>
            </div>
            <div className="absolute -bottom-6 -left-12 glass p-6 rounded-2xl shadow-xl animate-bounce">
              <div className="flex items-center gap-4">
                <div className="bg-green-500 w-3 h-3 rounded-full animate-pulse"></div>
                <p className="text-white text-sm font-medium">85% Retorno Promedio</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-white dark:bg-background-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-brand-800 dark:text-white">Cómo Funciona</h2>
            <div className="w-20 h-1.5 bg-primary mx-auto rounded-full"></div>
          </div>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="group p-8 rounded-3xl bg-slate-50 dark:bg-white/5 border border-transparent hover:border-primary/50 transition-all">
              <div className="w-16 h-16 bg-brand-800 dark:bg-primary rounded-2xl flex items-center justify-center mb-6 group-hover:rotate-6 transition-transform">
                <span className="material-icons-round text-white dark:text-brand-900 text-3xl">search</span>
              </div>
              <h3 className="text-2xl font-bold mb-4 dark:text-white">Explora</h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Descubre propiedades pre-analizadas y listas para evaluar a través de nuestra plataforma optimizada.
              </p>
            </div>
            <div className="group p-8 rounded-3xl bg-slate-50 dark:bg-white/5 border border-transparent hover:border-primary/50 transition-all">
              <div className="w-16 h-16 bg-brand-800 dark:bg-primary rounded-2xl flex items-center justify-center mb-6 group-hover:rotate-6 transition-transform">
                <span className="material-icons-round text-white dark:text-brand-900 text-3xl">analytics</span>
              </div>
              <h3 className="text-2xl font-bold mb-4 dark:text-white">Decide</h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Revisa información clave, reportes detallados y datos financieros para decidir sin miedo a equivocarte.
              </p>
            </div>
            <div className="group p-8 rounded-3xl bg-slate-50 dark:bg-white/5 border border-transparent hover:border-primary/50 transition-all">
              <div className="w-16 h-16 bg-brand-800 dark:bg-primary rounded-2xl flex items-center justify-center mb-6 group-hover:rotate-6 transition-transform">
                <span className="material-icons-round text-white dark:text-brand-900 text-3xl">account_balance</span>
              </div>
              <h3 className="text-2xl font-bold mb-4 dark:text-white">Invierte</h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Participa en subastas con soporte experto y asegura tu inversión en el mercado de Florida.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-50 dark:bg-brand-900/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div className="space-y-4">
              <h2 className="text-4xl font-display font-bold dark:text-white">Explora los Condados</h2>
              <p className="text-slate-500 dark:text-slate-400 max-w-xl">
                Revisa lo que ofrece cada uno, selecciona tus favoritos y mantente al día con las próximas fechas de subasta.
              </p>
            </div>
            <div className="flex gap-2 p-1 bg-white dark:bg-white/5 rounded-xl border border-slate-200 dark:border-white/10">
              <button className="px-4 py-2 bg-brand-800 dark:bg-primary text-white dark:text-brand-900 rounded-lg text-sm font-semibold">Grilla</button>
              <button className="px-4 py-2 text-slate-500 hover:text-brand-800 dark:hover:text-white transition-colors text-sm font-semibold">Lista</button>
              <button className="px-4 py-2 text-slate-500 hover:text-brand-800 dark:hover:text-white transition-colors text-sm font-semibold">Mapa</button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="group bg-white dark:bg-white/5 rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10 shadow-sm hover:shadow-xl transition-all duration-300">
              <div className="relative h-64">
                <img alt="Gainesville Alachua" className="w-full h-full object-cover" src="https://picsum.photos/seed/gainesville/600/400" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-100 group-hover:bg-black/40 transition-all">
                  <h3 className="text-3xl font-display font-bold text-white tracking-widest uppercase">Gainesville</h3>
                </div>
                <div className="absolute top-4 left-4">
                  <span className="bg-primary text-brand-900 text-[10px] font-black px-2 py-1 rounded uppercase tracking-tighter">Online</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <span className="material-icons-round text-brand-800 dark:text-primary">location_on</span>
                    <span className="font-bold dark:text-white">Alachua County</span>
                  </div>
                  <div className="flex text-primary">
                    <span className="material-icons-round text-sm">star</span>
                    <span className="material-icons-round text-sm">star</span>
                    <span className="material-icons-round text-sm">star</span>
                    <span className="material-icons-round text-sm text-slate-300 dark:text-slate-600">star</span>
                  </div>
                </div>
                <div className="space-y-3 text-sm text-slate-500 dark:text-slate-400">
                  <div className="flex justify-between">
                    <span>Oportunidad</span>
                    <div className="w-24 h-2 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                      <div className="w-3/4 h-full bg-green-500"></div>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span>Próxima Subasta</span>
                    <span className="text-brand-800 dark:text-white font-medium">12 Oct 2024</span>
                  </div>
                </div>
                <Link to="/condados/alachua" className="w-full mt-6 py-3 border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/10 rounded-xl font-bold transition-all flex items-center justify-center gap-2 dark:text-white">
                  Ver Detalles <span className="material-icons-round text-sm">chevron_right</span>
                </Link>
              </div>
            </div>
            <div className="group bg-white dark:bg-white/5 rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10 shadow-sm hover:shadow-xl transition-all duration-300">
              <div className="relative h-64">
                <img alt="Fort Lauderdale" className="w-full h-full object-cover" src="https://picsum.photos/seed/fortlauderdale/600/400" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-100 group-hover:bg-black/40 transition-all">
                  <h3 className="text-3xl font-display font-bold text-white tracking-widest uppercase">Fort Lauderdale</h3>
                </div>
                <div className="absolute top-4 left-4">
                  <span className="bg-primary text-brand-900 text-[10px] font-black px-2 py-1 rounded uppercase tracking-tighter">Online</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <span className="material-icons-round text-brand-800 dark:text-primary">location_on</span>
                    <span className="font-bold dark:text-white">Broward County</span>
                  </div>
                  <div className="flex text-primary">
                    <span className="material-icons-round text-sm">star</span>
                    <span className="material-icons-round text-sm">star</span>
                    <span className="material-icons-round text-sm">star</span>
                    <span className="material-icons-round text-sm">star</span>
                  </div>
                </div>
                <div className="space-y-3 text-sm text-slate-500 dark:text-slate-400">
                  <div className="flex justify-between">
                    <span>Oportunidad</span>
                    <div className="w-24 h-2 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                      <div className="w-[90%] h-full bg-green-500"></div>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span>Próxima Subasta</span>
                    <span className="text-brand-800 dark:text-white font-medium">18 Oct 2024</span>
                  </div>
                </div>
                <button className="w-full mt-6 py-3 border border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/10 rounded-xl font-bold transition-all flex items-center justify-center gap-2 dark:text-white">
                  Ver Detalles <span className="material-icons-round text-sm">chevron_right</span>
                </button>
              </div>
            </div>
            <div className="group bg-slate-100 dark:bg-white/5 rounded-2xl overflow-hidden border border-dashed border-slate-300 dark:border-white/10 flex flex-col items-center justify-center p-8 space-y-4">
              <div className="w-16 h-16 bg-slate-200 dark:bg-white/5 rounded-full flex items-center justify-center">
                <span className="material-icons-round text-slate-400">add_business</span>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-bold dark:text-white">Más Condados</h3>
                <p className="text-sm text-slate-500">Estamos analizando nuevas zonas de alta rentabilidad.</p>
              </div>
              <button className="text-sm text-primary font-bold hover:underline">Sugerir Condado</button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-white dark:bg-background-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl font-display font-bold dark:text-white">Escoge el plan ideal</h2>
            <p className="text-slate-500 dark:text-slate-400">Planes diseñados para cada etapa de tu camino como inversor.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-slate-50 dark:bg-white/5 rounded-3xl p-8 border border-slate-200 dark:border-white/10 hover:shadow-2xl transition-all relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <span className="material-icons-round text-8xl">cottage</span>
              </div>
              <h3 className="text-2xl font-bold mb-2 dark:text-white">Básico</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">Para quienes quieren aprender y entender el mercado.</p>
              <div className="mb-8">
                <span className="text-5xl font-bold dark:text-white">$20</span>
                <span className="text-slate-500">/mes</span>
              </div>
              <ul className="space-y-4 mb-10">
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-green-500 text-sm">check_circle</span>
                  <span className="dark:text-slate-300">Acceso a Inventario organizado</span>
                </li>
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-green-500 text-sm">check_circle</span>
                  <span className="dark:text-slate-300">Reglas claras de participación</span>
                </li>
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-green-500 text-sm">check_circle</span>
                  <span className="dark:text-slate-300">Calendario de subastas</span>
                </li>
              </ul>
              <button className="w-full py-4 bg-brand-800 dark:bg-white/10 hover:bg-brand-900 dark:hover:bg-white/20 text-white rounded-xl font-bold transition-all">
                Elegir Plan Básico
              </button>
            </div>
            <div className="bg-brand-800 dark:bg-brand-800 rounded-3xl p-8 border-2 border-primary shadow-2xl relative overflow-hidden transform scale-105">
              <div className="absolute top-4 right-4 bg-primary text-brand-900 text-[10px] font-black px-3 py-1 rounded-full uppercase">RECOMENDADO</div>
              <h3 className="text-2xl font-bold mb-2 text-white">Pro</h3>
              <p className="text-slate-300 text-sm mb-6">Para quienes están listos para comprar y necesitan validación experta.</p>
              <div className="mb-8">
                <span className="text-5xl font-bold text-white">$60</span>
                <span className="text-slate-300">/mes</span>
              </div>
              <ul className="space-y-4 mb-10">
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-primary text-sm">verified</span>
                  <span className="text-white">Todo lo del plan Básico</span>
                </li>
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-primary text-sm">verified</span>
                  <span className="text-white">Análisis de uso y restricciones</span>
                </li>
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-primary text-sm">verified</span>
                  <span className="text-white">Análisis de valor de mercado</span>
                </li>
                <li className="flex items-start gap-3 text-sm">
                  <span className="material-icons-round text-primary text-sm">verified</span>
                  <span className="text-white">Verificación de deudas y Liens</span>
                </li>
              </ul>
              <button className="w-full py-4 bg-primary hover:bg-opacity-90 text-brand-900 rounded-xl font-bold transition-all shadow-xl shadow-primary/20">
                Acceder Ahora Pro
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
