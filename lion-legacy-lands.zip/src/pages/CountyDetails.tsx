import { Link } from 'react-router-dom';

export default function CountyDetails() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <header className="mb-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="bg-primary/20 text-primary text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">Florida</span>
              <span className="text-slate-400 text-sm">Market Intelligence</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-extrabold mb-4">Alachua County</h1>
            <div className="flex flex-wrap gap-4 items-center text-sm">
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/10 text-accent-green rounded-full border border-green-500/20">
                <span className="material-icons-round text-sm">check_circle</span>
                <span>Mercado Estable</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500/10 text-primary rounded-full border border-primary/20">
                <span className="material-icons-round text-sm">local_fire_department</span>
                <span>Alta Demanda</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20">
                <span className="material-icons-round text-sm">school</span>
                <span>Sede Universitaria</span>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <Link to="/subastas" className="flex items-center justify-center gap-2 bg-primary text-background-dark px-8 py-4 rounded-xl font-bold text-lg hover:shadow-lg hover:shadow-primary/20 transition-all">
              <span className="material-icons-round">gavel</span>
              Ver Propiedades en Alachua
            </Link>
            <div className="flex gap-2">
              <Link to="/condados" className="flex-1 flex items-center justify-center gap-2 bg-slate-200 dark:bg-card-dark text-sm px-4 py-2 rounded-lg hover:bg-slate-300 dark:hover:bg-zinc-800 transition-colors">
                <span className="material-icons-round text-sm">arrow_back</span> Atrás
              </Link>
              <Link to="/" className="flex-1 flex items-center justify-center gap-2 bg-slate-200 dark:bg-card-dark text-sm px-4 py-2 rounded-lg hover:bg-slate-300 dark:hover:bg-zinc-800 transition-colors">
                <span className="material-icons-round text-sm">home</span> Inicio
              </Link>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-white/5">
              <h3 className="font-display font-bold mb-4 flex items-center gap-2">
                <span className="material-icons-round text-primary">map</span>
                Ubicación Geográfica
              </h3>
              <div className="aspect-square bg-slate-100 dark:bg-zinc-900 rounded-xl overflow-hidden relative border border-slate-200 dark:border-white/5 mb-4">
                <img alt="Mapa de Alachua County" className="w-full h-full object-contain p-4 opacity-80 dark:invert" src="https://picsum.photos/seed/map/400/400" referrerPolicy="no-referrer" />
                <div className="absolute bottom-4 left-4 right-4 bg-white/90 dark:bg-zinc-800/90 backdrop-blur p-3 rounded-lg text-xs leading-relaxed border border-slate-200 dark:border-white/10">
                  <strong>Límites:</strong> Columbia, Bradford, Union, Gilchrist, Levy, Marion y Putnam.
                </div>
              </div>
              <div className="flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1"><span className="material-icons-round text-sm">explore</span> Norte: Gainesville</span>
                <span className="flex items-center gap-1"><span className="material-icons-round text-sm">info</span> Región: Central Norte</span>
              </div>
            </div>

            <div className="bg-primary/5 dark:bg-primary/10 p-6 rounded-2xl border border-primary/20">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex-shrink-0 bg-primary/20 rounded-full flex items-center justify-center text-2xl">🦁</div>
                <div>
                  <h4 className="font-bold text-primary mb-1">Dato de León</h4>
                  <p className="text-sm dark:text-slate-300">Alachua es un mercado "Education-Driven". El 48% de la población tiene título universitario, lo que garantiza una base estable para inquilinos de calidad.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 flex flex-col gap-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-white/5">
                <span className="material-icons-round text-accent-green mb-3">trending_up</span>
                <div className="text-2xl font-bold font-display">$314,995</div>
                <div className="text-xs text-slate-500 uppercase font-bold tracking-tight">Precio Medio</div>
              </div>
              <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-white/5">
                <span className="material-icons-round text-blue-400 mb-3">group</span>
                <div className="text-2xl font-bold font-display">278,468</div>
                <div className="text-xs text-slate-500 uppercase font-bold tracking-tight">Población Total</div>
              </div>
              <div className="bg-white dark:bg-card-dark p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-white/5">
                <span className="material-icons-round text-primary mb-3">speed</span>
                <div className="text-2xl font-bold font-display">97 Días</div>
                <div className="text-xs text-slate-500 uppercase font-bold tracking-tight">Promedio en Mercado</div>
              </div>
            </div>

            <div className="bg-white dark:bg-card-dark p-8 rounded-2xl shadow-sm border border-slate-200 dark:border-white/5">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-display font-bold text-xl flex items-center gap-2">
                  <span className="material-icons-round text-primary">analytics</span>
                  Indicadores de Mercado
                </h3>
                <button className="text-xs font-bold text-primary hover:underline">VER TODOS LOS DATOS</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-accent-green rounded-full"></span> Economía
                  </h4>
                  <ul className="space-y-3">
                    <li className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                      <span className="text-sm">PBI del Condado</span>
                      <span className="font-bold">$20.93B</span>
                    </li>
                    <li className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                      <span className="text-sm">Ingreso Medio Hogar</span>
                      <span className="font-bold">$65,033</span>
                    </li>
                    <li className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                      <span className="text-sm">Tasa de Desempleo</span>
                      <span className="font-bold text-accent-green">3.1%</span>
                    </li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full"></span> Inversión
                  </h4>
                  <ul className="space-y-3">
                    <li className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                      <span className="text-sm">Crecimiento Anual</span>
                      <span className="font-bold text-accent-green">+4.8%</span>
                    </li>
                    <li className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                      <span className="text-sm">Presupuesto Público</span>
                      <span className="font-bold">$946M</span>
                    </li>
                    <li className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                      <span className="text-sm">Score de Riesgo</span>
                      <span className="font-bold text-blue-400">Bajo</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="mt-8 p-4 bg-slate-50 dark:bg-zinc-900 rounded-xl border border-slate-200 dark:border-white/5">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-xs font-bold uppercase text-slate-500">Tendencia de Precios 2024-2025</span>
                  <div className="flex gap-2">
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                  </div>
                </div>
                <div className="h-40 flex items-end justify-between gap-2">
                  <div className="w-full bg-primary/20 rounded-t h-1/2"></div>
                  <div className="w-full bg-primary/20 rounded-t h-2/3"></div>
                  <div className="w-full bg-primary/20 rounded-t h-1/3"></div>
                  <div className="w-full bg-primary/20 rounded-t h-3/4"></div>
                  <div className="w-full bg-primary/30 rounded-t h-2/3"></div>
                  <div className="w-full bg-primary/40 rounded-t h-4/5"></div>
                  <div className="w-full bg-primary/50 rounded-t h-3/4"></div>
                  <div className="w-full bg-primary/60 rounded-t h-full"></div>
                  <div className="w-full bg-primary/70 rounded-t h-5/6"></div>
                  <div className="w-full bg-primary rounded-t h-full"></div>
                </div>
                <div className="flex justify-between mt-2 text-[10px] text-slate-400">
                  <span>ENE 24</span>
                  <span>JUN 24</span>
                  <span>DIC 24</span>
                  <span>HOY</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-display font-bold flex items-center gap-3">
            <span className="material-icons-round text-primary">contact_phone</span>
            Directorio del Condado
          </h3>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-slate-200 dark:hover:bg-zinc-800 rounded-lg transition-colors">
              <span className="material-icons-round">filter_list</span>
            </button>
            <button className="p-2 hover:bg-slate-200 dark:hover:bg-zinc-800 rounded-lg transition-colors">
              <span className="material-icons-round">search</span>
            </button>
          </div>
        </div>
        <div className="bg-white dark:bg-card-dark rounded-2xl shadow-sm border border-slate-200 dark:border-white/5 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 dark:bg-zinc-900/50">
              <tr>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">Departamento</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">Teléfono</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">Correo Electrónico</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">Encargado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-white/5">
              <tr className="hover:bg-slate-50 dark:hover:bg-zinc-800/50 transition-colors">
                <td className="px-6 py-4">
                  <span className="text-sm font-bold bg-blue-500/10 text-blue-500 px-2 py-1 rounded">Planning & Zoning</span>
                </td>
                <td className="px-6 py-4 text-sm">352-374-5249</td>
                <td className="px-6 py-4 text-sm text-primary">planning@alachuacounty.us</td>
                <td className="px-6 py-4 text-sm font-medium">Jeffrey L. Hays</td>
              </tr>
              <tr className="hover:bg-slate-50 dark:hover:bg-zinc-800/50 transition-colors">
                <td className="px-6 py-4">
                  <span className="text-sm font-bold bg-amber-500/10 text-amber-500 px-2 py-1 rounded">Building Division</span>
                </td>
                <td className="px-6 py-4 text-sm">352-374-5243</td>
                <td className="px-6 py-4 text-sm text-primary">building@alachuacounty.us</td>
                <td className="px-6 py-4 text-sm font-medium">—</td>
              </tr>
              <tr className="hover:bg-slate-50 dark:hover:bg-zinc-800/50 transition-colors">
                <td className="px-6 py-4">
                  <span className="text-sm font-bold bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded">Transportation</span>
                </td>
                <td className="px-6 py-4 text-sm">352-374-5249</td>
                <td className="px-6 py-4 text-sm text-primary">amoss@alachuacounty.us</td>
                <td className="px-6 py-4 text-sm font-medium">—</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h3 className="text-2xl font-display font-bold mb-6 flex items-center gap-3">
          <span className="material-icons-round text-primary">location_city</span>
          Ciudades Destacadas
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-card-dark p-4 rounded-xl border border-slate-200 dark:border-white/5 text-center hover:border-primary transition-colors cursor-pointer group">
            <div className="font-bold text-lg group-hover:text-primary transition-colors">Gainesville</div>
            <div className="text-xs text-slate-500 uppercase">Principal Hub</div>
          </div>
          <div className="bg-white dark:bg-card-dark p-4 rounded-xl border border-slate-200 dark:border-white/5 text-center hover:border-primary transition-colors cursor-pointer group">
            <div className="font-bold text-lg group-hover:text-primary transition-colors">High Springs</div>
            <div className="text-xs text-slate-500 uppercase">Eco-Turismo</div>
          </div>
          <div className="bg-white dark:bg-card-dark p-4 rounded-xl border border-slate-200 dark:border-white/5 text-center hover:border-primary transition-colors cursor-pointer group">
            <div className="font-bold text-lg group-hover:text-primary transition-colors">Alachua City</div>
            <div className="text-xs text-slate-500 uppercase">Residencial</div>
          </div>
          <div className="bg-white dark:bg-card-dark p-4 rounded-xl border border-slate-200 dark:border-white/5 text-center hover:border-primary transition-colors cursor-pointer group">
            <div className="font-bold text-lg group-hover:text-primary transition-colors">Newberry</div>
            <div className="text-xs text-slate-500 uppercase">Crecimiento Rápido</div>
          </div>
        </div>
      </section>
    </div>
  );
}
